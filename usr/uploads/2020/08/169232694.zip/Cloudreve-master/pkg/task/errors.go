package task

import "errors"

var (
	// ErrUnknownTaskType 未知任务类型
	ErrUnknownTaskType = errors.New("未知任务类型")
)
