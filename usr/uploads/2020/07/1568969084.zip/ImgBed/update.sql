INSERT INTO `img_config` (`k`, `v`) VALUES
('username', 'admin'),
('password', '123456');