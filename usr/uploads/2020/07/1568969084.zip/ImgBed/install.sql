CREATE TABLE IF NOT EXISTS `img_black_ip` (
  `id` int(10) unsigned NOT NULL,
  `ip` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `addtime` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
CREATE TABLE IF NOT EXISTS `img_config` (
  `k` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `v` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
INSERT INTO `img_config` (`k`, `v`) VALUES
('sitename', '烟雨图床'),
('copy', '烟雨寒云'),
('allowtype', 'jpg,png,gif,jpeg,JPG,PNG,GIF,JPEG'),
('REPO', 'image'),
('USER', 'YanYuHanYun'),
('MAIL', 'admin@yyhy.me'),
('TOKEN', '123456'),
('title', '极简高速外链图床'),
('keywords', '烟雨图床,Github图床,烟雨,烟雨寒云'),
('description', '烟雨寒云旗下极简高速外链图床，轻简好用，完全免费！'),
('footer', '本站由最可爱的QAQ_CORE强力驱动'),
('nav', '<a href="https://www.yyhy.me/" target="__blank"><span class="icon-directions"></span> 博客</a>|<a href="https://yf.yyhy.me/" target="__blank"><span class="icon-wallet"></span> 赞助</a>'),
('max_upload', '10485760'),
('max_uploads', '10'),
('username', 'admin'),
('password', '123456'),
('admin_img', 'https://cdn.jsdelivr.net/gh/YanYuHanYun/cdn/c93be513329ada026df744f50a9fbce4.jpg');
CREATE TABLE IF NOT EXISTS `img_imgs` (
  `img_id` int(10) unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `img_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `sha` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `height` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `width` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `mime` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `size` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `addtime` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
ALTER TABLE `img_black_ip` ADD PRIMARY KEY (`id`);
ALTER TABLE `img_config` ADD PRIMARY KEY (`k`);
ALTER TABLE `img_imgs` ADD PRIMARY KEY (`img_id`);
ALTER TABLE `img_black_ip` MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
ALTER TABLE `img_imgs` MODIFY `img_id` int(10) unsigned NOT NULL AUTO_INCREMENT;