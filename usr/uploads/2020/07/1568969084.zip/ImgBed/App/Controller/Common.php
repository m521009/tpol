<?php

namespace App\Controller;

use App\Model\Config;
use QAQ\Kernel\Controller;
use QAQ\Kernel\Session;

class Common extends Controller
{
    public function __construct()
    {
        Config::site_info();
        //检查根目录是否有更新包
        if (is_file(QAQ_CORE_DIR . 'update.zip')) {
            @unlink(QAQ_CORE_DIR . 'update.zip');
        }
    }

    public function verify_login()
    {
        $session = Session::get('admin_auth');
        if (!$session || !$session['username'] || !$session['password'] || $session['username'] != config('username') || $session['password'] != config('password')) return false;
        return true;
    }
}