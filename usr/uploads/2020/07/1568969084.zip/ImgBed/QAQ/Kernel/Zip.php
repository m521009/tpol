<?php

namespace QAQ\Kernel;
class Zip
{

}